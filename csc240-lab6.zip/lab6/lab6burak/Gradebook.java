package lab6burak;

import java.util.Scanner;

public class Gradebook {
	private Student[] students;
    private int count;

    public Gradebook(int capacity) {
    	students = new Student[capacity];
	    count = 0;
	    }

    public void addStudent(Student student) {
    	if (count < students.length) {
    		students[count] = student;
	        count++;
	        } 
    	else {
    		System.out.println("Gradebook is full.");
	        }
	    }

    public void sortStudents() {
    	Sorting.selectionSort(students);
	    }

    public void printStudents() {
    	for (int i = 0; i < count; i++) {
    		System.out.println(students[i]);
	        }
	    }


	}


