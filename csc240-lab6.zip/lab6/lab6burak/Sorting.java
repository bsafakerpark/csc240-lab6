package lab6burak;

public class Sorting {
	    public static void selectionSort(Comparable[] array) {
	      for (int i = 0; i < array.length - 1; i++) 
	      {
	          int maxIndex = i;
		      for (int j = i + 1; j < array.length; j++) 
		      {
		               if (array[j].compareTo(array[maxIndex]) < 0) 
		               {
		                    maxIndex = j;
		               }
	           }
		   Comparable temp = array[i];
		   array[i] = array[maxIndex];
		   array[maxIndex] = temp;
	       }
	    }
	}

