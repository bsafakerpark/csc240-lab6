package lab6burak;

	public class Student implements Comparable<Student> {
	    private String firstName;
	    private String lastName;
	    private int score;

	public Student(String firstName, String lastName, int score) {
	    this.firstName = firstName;
	    this.lastName = lastName;
	    this.score = score;
	    }

	public String getFirstName() {
		return firstName;
	    }

	public String getLastName() {
		return lastName;
	    }

	public int getScore() {
		return score;
	    }
	
	public void setFirstName(String fName)
	{
		this.firstName = fName;
	}
	
	public void setlastName(String lName)
	{
		this.lastName = lName;
	}

	public void setScore(int sco)
	{
		this.score = sco;
	}


	@Override
	public int compareTo(Student other) {
		return Integer.compare(other.score, this.score); // Descending order
	    }

	@Override
	    public String toString() {
	        return firstName + " " + lastName + " " + score;
	    }
	}

