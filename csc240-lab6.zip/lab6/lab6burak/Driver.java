package lab6burak;
import java.util.Scanner;

public class Driver {
	    public static void main(String[] args) {
	    	Scanner scanner = new Scanner(System.in);
	        Gradebook gradebook = new Gradebook(5);       
	        
	        for (int i = 0; i < 5; i++) {
	        	System.out.print("Enter student <firstName> <lastName> <score>:"  );
	        	gradebook.addStudent(new Student(scanner.next(), scanner.next(), scanner.nextInt()));

	        }
	        gradebook.sortStudents();
	        gradebook.printStudents();
	        
	        scanner.close();
	    }
	}



